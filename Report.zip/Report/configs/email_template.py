def get_template():
    return 'Hello {name},\nThis is your automated report.'
